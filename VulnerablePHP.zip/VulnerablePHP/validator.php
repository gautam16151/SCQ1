<?php
   
  class Validator 
  {
    private $reg_exp1 = "/^[a-zA-Z0-9@$%^&()_]*$/";       // RegExp to accept Case Insensitive Alphabets, digits and some special Chars( @ $ % ^ & ( ) _ )
    private $reg_exp2 = "/^[a-zA-Z0-9@_.]*$/";           // RegExp to accept Case Insensitive Alphabets, digits and @ _ and .
    private $flag;
    public $word;
  
 
    function __construct($w)
    {
      $this->word = $w;
    }
  
    function getWord()
    {
      return $this->word;
    }
  
    function chkAlpha()
    {
     if (preg_match($this->reg_exp1, $this->word, $match))
      {
          $this->flag = 1;
          return $this->flag;
      }
      else
      {
          $this->flag = 0;
          return $this->flag;
      }
    }

     function chkvalidmail()
    {
     if (preg_match($this->reg_exp2, $this->word, $match))
      {
          $this->flag = 1;
          return $this->flag;
      }
      else
      {
          $this->flag = 0;
          return $this->flag;
      }
    }
  }
 
 